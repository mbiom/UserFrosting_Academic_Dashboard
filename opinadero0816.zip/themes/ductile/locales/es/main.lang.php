<?php
# -- BEGIN LICENSE BLOCK ---------------------------------------
#
# This file is part of Dotclear 2.
#
# Copyright (c) 2003-2013 Olivier Meunier & Association Dotclear
# Licensed under the GPL version 2.0 license.
# See LICENSE file or
# http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#
# -- END LICENSE BLOCK -----------------------------------------#
#
#
#		  DOT NOT MODIFY THIS FILE !




$GLOBALS['__l10n']['reactions'] = 'reacciones';
$GLOBALS['__l10n']['Add ping'] = 'Agregar un retroenlace';
$GLOBALS['__l10n']['Suggestions:'] = 'Sugerencias:';
$GLOBALS['__l10n']['Go to homepage'] = 'Regresar al inicio';
$GLOBALS['__l10n']['Use search form'] = 'Buscar';
$GLOBALS['__l10n']['Explore archives'] = 'Explorar los archivos';
$GLOBALS['__l10n']['toDay'] = 'al';
$GLOBALS['__l10n']['FromDay'] = 'Del';
$GLOBALS['__l10n']['From'] = 'Del';
$GLOBALS['__l10n']['By category'] = 'Por categoría';
$GLOBALS['__l10n']['By date'] = 'Por fecha';
$GLOBALS['__l10n']['By tag'] = 'Por tag';
$GLOBALS['__l10n']['URL you\'ve tried has typos, or the page has been deleted or moved.'] = 'Su URL está equivocada o la página fue borrada o desplazada.';
