<?php
# -- BEGIN LICENSE BLOCK ---------------------------------------
#
# This file is part of Dotclear 2.
#
# Copyright (c) 2003-2013 Olivier Meunier & Association Dotclear
# Licensed under the GPL version 2.0 license.
# See LICENSE file or
# http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#
# -- END LICENSE BLOCK -----------------------------------------#
#
#
#		  DOT NOT MODIFY THIS FILE !




$GLOBALS['__l10n'][''] = 'Content-Type: text/plain; charset=UTF-8
';
$GLOBALS['__l10n']['File %s does not exist and directory %s is not writable.'] = 'Le fichier %s n\'existe pas et le répertoire %s n\'est pas accessible en écriture.';
$GLOBALS['__l10n']['Style sheet upgraded.'] = 'Feuille de style mise à jour.';
$GLOBALS['__l10n']['Style sheet:'] = 'Feuille de style :';
