
## Setting up a global .gitignore for all projects

http://islegend.com/development/setting-global-gitignore-mac-windows/